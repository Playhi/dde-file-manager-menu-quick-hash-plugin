# net.playhi.dde-file-manager-menu-quick-hash-plugin

Add a group of items for calculating MD4, MD5, SHA1, SHA224, SHA256, SHA384, SHA512, SHA3_224, SHA3_256, SHA3_384, SHA3_512 in the dde-file-manager right-click menu.

###### ___[Old dde-file-manager-menu-quick-hash-plugin-third-party repository](https://github.com/Playhi/dde-file-manager-menu-quick-hash-plugin-third-party)___
