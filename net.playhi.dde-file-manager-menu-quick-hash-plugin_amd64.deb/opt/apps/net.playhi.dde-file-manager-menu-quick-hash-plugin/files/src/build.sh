#!/bin/sh
cd $(cd `dirname $0`; pwd)
go build main.go
